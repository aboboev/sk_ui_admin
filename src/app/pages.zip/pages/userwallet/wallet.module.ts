import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from "@angular/router";
import {SIDEBAR_TOGGLE_DIRECTIVES} from "../../shared/sidebar.directive";
import {SharedModule} from "../../shared/shared.module";
import {WalletComponent} from "./wallet.component";
import {WalletRoutes} from "./wallet.routing";


@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(WalletRoutes),
        SharedModule
    ],
    declarations: [
        WalletComponent,
    ]
})

export class WalletModule { }
