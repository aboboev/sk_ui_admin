import {Routes, RouterModule} from '@angular/router';
import {AuthLayoutComponent} from "../../layouts/auth/auth-layout.component";
import {ComingSoonComponent} from "../../shared/components/coming/coming.component";
import {WalletComponent} from "./wallet.component";

export const WalletRoutes: Routes = [
    {
        path: '',
        component: WalletComponent
    }
];
